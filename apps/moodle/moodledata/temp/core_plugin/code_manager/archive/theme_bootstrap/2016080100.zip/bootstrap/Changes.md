Version Information
===================
Version 3.1.0

- update bootstrap to 3.3.6
- undid margin: 0 0 10px 25 on all ul, ol elements
- added a theme folder

Version 3.0.0

- Update version number
- Add travis support
- Styling for Feedback module
- PDF Annotation fixes
- Minor styling fixes